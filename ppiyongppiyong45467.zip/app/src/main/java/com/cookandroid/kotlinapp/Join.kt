package com.cookandroid.kotlinapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import kotlinx.android.synthetic.main.header.*
import kotlinx.android.synthetic.main.join.*
import kotlinx.android.synthetic.main.join.txtId
import kotlinx.android.synthetic.main.join.txtPw
import kotlinx.android.synthetic.main.login.*
import org.json.JSONObject

class Join : AppCompatActivity() {
// 이메일중복o 비밀번호중복o 이름형식x 이메일로본인확인x, 핸드폰본인확인x,
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.join)
        txtHeaderTitle.text="회원가입";

        var idchk = false

        val btnSubmit1 = findViewById<Button>(R.id.btnSubmit)
        val btnIdChk1 = findViewById<Button>(R.id.btnIdChk)

        btnIdChk1.setOnClickListener{
            val url = "http://61.84.24.251:49090/siren/idoverlap"
            //textView.text = ""


            // Post parameters
            // Form fields and values
            val params = HashMap<String,String>()
            params["userid"] = txtEmail.text.toString()
            val jsonObject = JSONObject(params)
            // Volley post request with parameters
            val request = JsonObjectRequest(Request.Method.POST,url,jsonObject,
                Response.Listener { response ->
                    // Process the json
                    try {
                        println(" Response: $response")

                        if(response.getString("result").equals("T")){

                            Toast.makeText(this, "사용 가능한 아이디 입니다.",Toast.LENGTH_SHORT).show()
                            idchk = true
                        }else {
                            Toast.makeText(this, "이미 사용 중인 아이디 입니다.",Toast.LENGTH_SHORT).show()
                            idchk = false
                        }

                        //println(response.getString("result"))
                        //txtId.text = "Response: $response"
                    }catch (e:Exception){
                        println(" Exception: $e")
                        //txtPw.text = "Exception: $e"
                    }

                }, Response.ErrorListener{
                    // Error in request
                    println(" Volley error: $it")
                    //txtId.text = "Volley error: $it"
                }
            )

            request.retryPolicy = DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                // 0 means no retry
                0, // DefaultRetryPolicy.DEFAULT_MAX_RETRIES = 2
                1f // DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            // Add the volley post request to the request queue
            VolleySingleton.getInstance(this).addToRequestQueue(request)
        }


        btnSubmit1.setOnClickListener{
            val url = "http://61.84.24.251:49090/siren/test2"
            //textView.text = ""

            // Post parameters
            // Form fields and values
            val params = HashMap<String,String>()
            params["userid"] = txtEmail.text.toString()
            params["user_password"] = txtPw.text.toString()
            params["name"] = txtName.text.toString()
            params["date_of_birth"] = txtBirth.text.toString()
            params["tel"] = txtPhone.text.toString()


            val jsonObject = JSONObject(params)
            // Volley post request with parameters
            val request = JsonObjectRequest(Request.Method.POST,url,jsonObject,
                Response.Listener { response ->
                    // Process the json
                    try {
                        println(" Response: $response")

                        if(response.getString("result").equals("T")){

                            Toast.makeText(this, " 회원가입을 축하합니다.",Toast.LENGTH_SHORT).show()
                            val intent = Intent(this, JoinOk::class.java)
                            startActivity(intent)

                        }else {
                            Toast.makeText(this, " 회원가입에 실패하셨습니다.", Toast.LENGTH_SHORT).show()
                            if ( idchk == false ) {
                                Toast.makeText(this, " 아이디 중복을 확인 해주세요.", Toast.LENGTH_SHORT).show()
                            }
                            if ( txtPw.equals(txtPwChk) ){

                            }else
                                txtpwchk.setText("재입력한 비밀번호을 확인 해주세요.")
                        }

                        //println(response.getString("result"))
                        //txtId.text = "Response: $response"
                    }catch (e:Exception){
                        println(" Exception: $e")
                        //txtPw.text = "Exception: $e"
                    }

                }, Response.ErrorListener{
                    // Error in request
                    println(" Volley error: $it")
                    //txtId.text = "Volley error: $it"
                }
            )

            request.retryPolicy = DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                // 0 means no retry
                0, // DefaultRetryPolicy.DEFAULT_MAX_RETRIES = 2
                1f // DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            // Add the volley post request to the request queue
            VolleySingleton.getInstance(this).addToRequestQueue(request)
        }
        btnHeaderBack.setOnClickListener {
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }
    }
}

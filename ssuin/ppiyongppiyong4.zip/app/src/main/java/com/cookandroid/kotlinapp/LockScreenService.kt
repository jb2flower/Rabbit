package com.cookandroid.kotlinapp

import android.app.Service
import android.content.Intent
import android.content.IntentFilter
import android.os.IBinder
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.NotificationManager.IMPORTANCE_NONE
import android.content.Context
import android.os.Build

class LockScreenService : Service() {
    //화면이 꺼질때 브로드캐스트 메세지를 수신하는 리서버
    var receiver: ScreenOffReceiver? =null
    private val ANDROID_CHANNEL_ID="com.cookandroid.kotlinapp"
    private val NOTIFICATION_ID=999
    override fun onCreate() {
        super.onCreate()
        if (receiver==null){
            receiver=ScreenOffReceiver()
            val filter=IntentFilter(Intent.ACTION_SCREEN_OFF)
            registerReceiver(receiver,filter)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return super.onStartCommand(intent, flags, startId)
        if (intent!=null){
            if (intent.action==null){
                //서비스가 최초실행이 아닌경우 oncreate가 불리지 않을 수 있음.
                //이 경우 receiver가 널이면 새로 생성하고 등록한다.
                if (receiver==null){
                    receiver= ScreenOffReceiver()
                    val filter=IntentFilter(Intent.ACTION_SCREEN_OFF)
                    registerReceiver(receiver,filter)
                }
            }
        }
        if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.O){
            //notification 채널생성
            //val chan=NotificationChannel(ANDROID_CHANNEL_ID,"MyService",NotificationManager,IMPORTANCE_NONE)
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return null
    }
}

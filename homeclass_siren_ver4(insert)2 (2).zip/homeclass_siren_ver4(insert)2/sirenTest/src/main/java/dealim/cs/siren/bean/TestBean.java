package dealim.cs.siren.bean;



public class TestBean {
	private String userid;
	private String name;
	private String tel;
	private String addr;
	private String user_password;
	private String user_email;
	private String medicament;
	private String blood_type;
	private String date_of_birth;
	private String user_weight;
	private String oft_hospital;
	private String disease_name;
	
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddr() {
		return addr;
	}
	public void setAddr(String addr) {
		this.addr = addr;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getMedicament() {
		return medicament;
	}
	public void setMedicament(String medicament) {
		this.medicament = medicament;
	}
	public String getBlood_type() {
		return blood_type;
	}
	public void setBlood_type(String blood_type) {
		this.blood_type = blood_type;
	}
	public String getDate_of_birth() {
		return date_of_birth;
	}
	public void setDate_of_birth(String date_of_birth) {
		this.date_of_birth = date_of_birth;
	}
	public String getUser_weight() {
		return user_weight;
	}
	public void setUser_weight(String user_weight) {
		this.user_weight = user_weight;
	}
	public String getOft_hospital() {
		return oft_hospital;
	}
	public void setOft_hospital(String oft_hospital) {
		this.oft_hospital = oft_hospital;
	}
	public String getDisease_name() {
		return disease_name;
	}
	public void setDisease_name(String disease_name) {
		this.disease_name = disease_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
}

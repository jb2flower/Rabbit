package com.cookandroid.kotlinapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.id_find.*
import kotlinx.android.synthetic.main.pw_find.*

class PW_find : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.pw_find)

        button11.setOnClickListener {
            val intent = Intent(this,ID_find::class.java)
            startActivity(intent)
        }

        button12.setOnClickListener {
            val intent = Intent(this, PW_change2::class.java)
            startActivity(intent)
        }
    }
}

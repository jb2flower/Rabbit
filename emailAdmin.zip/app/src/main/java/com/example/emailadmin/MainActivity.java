package com.example.emailadmin;

//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//}
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

//import com.example.sample.R;

public class MainActivity extends AppCompatActivity
{
    private GMailSender m;

    EditText et_content;
    EditText et_title;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btn_send = (Button) this.findViewById(R.id.btn_send);
        et_content = (EditText) findViewById(R.id.et_content);
        et_title = (EditText) findViewById(R.id.et_title);

        btn_send.setOnClickListener(new View.OnClickListener()
        {
            public void onClick(View view)
            {
                GMailSender sender = new GMailSender("jb2flower@gmail.com", "tlazlstm2375"); // SUBSTITUTE

                if (android.os.Build.VERSION.SDK_INT > 9)
                {

                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
                            .permitAll().build();

                    StrictMode.setThreadPolicy(policy);

                }
                // HERE
                try
                {    //문자를 et_content에서 입력받아서, sender(보내는사람) 으로부터 recipients(받는사람)에게 보냄.
                     //그러니까 et_content에 암호 난수를 정해 값을 넣고 서버에서 메일을 보내는식. 모바일 어플을 통하는거라 핸드폰에서만 됨
                    sender.sendMail(et_title.getText().toString(), // subject.getText().toString(),
                            et_content.getText().toString(), // body.getText().toString(),
                            "jb2flower@gmail.com", // from.getText().toString(),
                            "jb2flower@naver.com" // to.getText().toString()
                    );

                    toast();
                } catch (Exception e)
                {
                    Log.e("SendMail", e.getMessage(), e);
                }
            }
        });
    }

    public void toast()
    {
        Toast.makeText(this, "전송되었습니다.", Toast.LENGTH_SHORT).show();
        finish();
    }
}



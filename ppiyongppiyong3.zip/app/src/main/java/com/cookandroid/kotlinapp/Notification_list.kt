package com.cookandroid.kotlinapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class Notification_list : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.notification_list)
    }
}

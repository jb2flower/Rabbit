package com.cookandroid.kotlinapp

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import com.android.volley.DefaultRetryPolicy
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import kotlinx.android.synthetic.main.header.*
import kotlinx.android.synthetic.main.login.*
import org.json.JSONObject

class Login : AppCompatActivity() {

     lateinit var asni : String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)
        txtHeaderTitle.text="로그인";

        val btn = findViewById<Button>(R.id.btnLogin)

        btn.setOnClickListener{
            val url = "http://61.84.24.251:49090/siren/test3"
            //textView.text = ""

            // Post parameters
            // Form fields and values
            val params = HashMap<String,String>()
            params["userid"] = txtId.text.toString()
            params["user_password"] = txtPw.text.toString()

            val jsonObject = JSONObject(params)
            print("eee")
            // Volley post request with parameters
            val request = JsonObjectRequest(Request.Method.POST,url,jsonObject,
                Response.Listener { response ->
                    // Process the json
                    try {
                        println(" Response: $response")

                        if (response.getString("result").equals("T")){

                            val intent = Intent(this, Main::class.java)
                            startActivity(intent)
                        }else
                            Toast.makeText(this, "아이디나 비밀번호가 잘못되었습나다.",Toast.LENGTH_SHORT).show()
                        //println(response.getString("result"))
                        //txtId.text = "Response: $response"
                    }catch (e:Exception){
                        println(" Exception: $e")
                        //txtPw.text = "Exception: $e"
                    }

                }, Response.ErrorListener{
                    // Error in request
                    println(" Volley error: $it")
                    //txtId.text = "Volley error: $it"
                }
            )

            request.retryPolicy = DefaultRetryPolicy(
                DefaultRetryPolicy.DEFAULT_TIMEOUT_MS,
                // 0 means no retry
                0, // DefaultRetryPolicy.DEFAULT_MAX_RETRIES = 2
                1f // DefaultRetryPolicy.DEFAULT_BACKOFF_MULT
            )

            // Add the volley post request to the request queue
            VolleySingleton.getInstance(this).addToRequestQueue(request)
        }

        btnFind.setOnClickListener {
            val intent = Intent(this, ID_find::class.java)
            startActivity(intent)
        }

        btnJoin.setOnClickListener {
            val intent = Intent(this, Join::class.java)
            startActivity(intent)
        }
    }
}
